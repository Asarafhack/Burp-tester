import requests

def perform_scan(url):
    vulnerabilities = []
    
    try:
        # Example vulnerability check: Check for open redirect
        response = requests.get(url)
        if "Location" in response.headers:
            vulnerabilities.append("Potential open redirect vulnerability")

        # Example vulnerability check: Basic XSS
        xss_payloads = [
            '<script>alert(1)</script>',
            '<img src=x onerror=alert(1)>',
            '<svg/onload=alert(1)>',
            '<a href="javascript:alert(1)">Click Me</a>',
            '<body onload=alert(1)>',
            '<input type="text" value="<script>alert(1)</script>">'
        ]
        for payload in xss_payloads:
            if payload in response.text:
                vulnerabilities.append("Potential XSS vulnerability detected: " + payload)
    except requests.RequestException as e:
        vulnerabilities.append("Error performing scan: " + str(e))

    return vulnerabilities
