document.addEventListener("DOMContentLoaded", function() {
    const scanForm = document.getElementById('scanForm');
    const resultDiv = document.getElementById('result');

    scanForm.addEventListener('submit', function(event) {
        event.preventDefault();

        const urlInput = document.getElementById('urlInput').value;
        if (!urlInput) {
            alert('Please enter a URL');
            return;
        }

        fetch('/scan', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                url: urlInput
            })
        })
        .then(response => response.json())
        .then(data => {
            resultDiv.innerHTML = '';
            data.forEach(vulnerability => {
                const vulnerabilityDiv = document.createElement('div');
                vulnerabilityDiv.textContent = vulnerability;
                resultDiv.appendChild(vulnerabilityDiv);
            });
        })
        .catch(error => {
            resultDiv.innerHTML = '';
            const errorDiv = document.createElement('div');
            errorDiv.textContent = 'An error occurred: ' + error.message;
            resultDiv.appendChild(errorDiv);
        });
    });
});
