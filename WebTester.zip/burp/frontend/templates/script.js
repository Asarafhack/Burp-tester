document.getElementById('scan-form').addEventListener('submit', function(event) {
    event.preventDefault();
    const url = document.getElementById('url').value;
    
    fetch('/scan', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify({ url: url }),
    })
    .then(response => response.json())
    .then(data => {
        let resultsDiv = document.getElementById('results');
        resultsDiv.innerHTML = '';

        if (data.length > 0) {
            data.forEach(vulnerability => {
                let p = document.createElement('p');
                p.textContent = vulnerability;
                resultsDiv.appendChild(p);
            });
        } else {
            resultsDiv.textContent = 'No vulnerabilities found.';
        }
    })
    .catch(error => console.error('Error:', error));
});
